<?php
// Heading
$_['heading_title']    = 'Marketing';

// Text
$_['text_success']     = 'Marketing modificado com sucesso!';
$_['text_list']        = 'Listando marketing';

// Column
$_['column_name']      = 'Marketing';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo marketing!';

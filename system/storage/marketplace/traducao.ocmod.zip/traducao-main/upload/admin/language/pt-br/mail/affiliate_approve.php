<?php
// Text
$_['text_subject']  = '%s - Sua conta de afiliado foi aprovada!';
$_['text_welcome']  = 'Obrigado por se cadastrar na loja %s!';
$_['text_login']    = 'Sua conta foi aprovada, agora você pode acessar sua conta utilizando seu e-mail e sua senha através de nossa loja:';
$_['text_services'] = 'Ao acessar sua conta, você poderá gerar códigos de rastreamento, acompanhar o pagamento de suas comissões e editar as informações da sua conta.';
$_['text_thanks']   = 'Atenciosamente,';

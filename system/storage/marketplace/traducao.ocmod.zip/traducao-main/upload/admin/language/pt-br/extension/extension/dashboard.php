<?php
// Heading
$_['heading_title']     = 'Painéis';

// Text
$_['text_success']      = 'Painel modificado com sucesso!';
$_['text_list']         = 'Listando painéis';

// Column
$_['column_name']       = 'Painel';
$_['column_width']      = 'Colunas';
$_['column_status']     = 'Situação';
$_['column_sort_order'] = 'Posição';
$_['column_action']     = 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar as extensões do tipo painel!';

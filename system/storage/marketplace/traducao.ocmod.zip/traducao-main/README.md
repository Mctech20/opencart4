[![version][opencart-badge]][CHANGELOG] [![license][licenca-badge]][LICENSE]

### Apresentação

Essa tradução para português do Brasil do OpenCart, é mantida e revisada por OpenCart Brasil.

Segue o link para download do pacote de instalação atualizado:

https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=19865

### Instalação ou atualização da tradução

http://www.opencartbrasil.com.br/instalando-traducao-opencart

### Dúvidas

Antes de enviar uma Issue, pesquise em nosso fórum [clicando aqui](https://forum.opencartbrasil.com.br/).

[opencart-badge]: https://img.shields.io/badge/opencart-3.0-blue.svg
[CHANGELOG]: ./CHANGELOG.md
[licenca-badge]: https://img.shields.io/badge/licença-GPLv3-blue.svg
[LICENSE]: ./LICENSE
[OCMOD]: https://github.com/opencart/opencart/wiki/Modification-System
